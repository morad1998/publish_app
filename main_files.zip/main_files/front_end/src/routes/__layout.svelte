<script lang="ts">
	import Header from '$lib/header/Header.svelte';
	import Footer from '$lib/footer/Footer.svelte';
	import '../app.css';
</script>

<div class='p-8 max-w-6xl mx-auto'>
	
	<div >
		<Header />
	</div>

	
	<!-- <main class="flex justify-center items-center"> -->
			<slot />
	<!-- </main>	 -->

	<div >
		<Footer />
	</div>

</div>

<style></style>
