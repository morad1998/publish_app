<script>
    export let offerdatum;
    import {fade} from 'svelte/transition';
</script>
<!-- <a href={`/offerdatum/${offerdatum.id}`}>
    <img src={offerdatum.image} alt={offerdatum.name}>
    <h2>{offerdatum.name}. Short Description</h2>
</a> -->

<div class="card w-50 bg-base-100 shadow-xl image-full">
    <figure><img src="https://coffee.alexflipnote.dev/random" alt={offerdatum.name} /></figure>
    <div class="card-body">
      <h2 class="card-title">{offerdatum.name}</h2>
      <p>Offer Short Description.{offerdatum.id}</p>
      <div class="card-actions justify-end">
        <a href={`/offers/offer_details/${offerdatum.id}`} transition:fade><button class="btn btn-primary">More Details</button></a>
      </div>
    </div>
  </div>