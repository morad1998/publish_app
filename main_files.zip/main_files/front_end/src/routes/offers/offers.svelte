<script>
    	import {offerData} from '../../stores/offers'
        import offerdatum from '../../routes/offers/components/offercard.svelte'
        import Offercard from '../../routes/offers/components/offercard.svelte'
        let searchTerm = "";
        let filteredOffers = [];

        $:{
            if (searchTerm) {
                //search
                filteredOffers = $offerData.filter( offerdatum => offerdatum.name.toLowerCase().includes(searchTerm.toLowerCase()));
            } else {
                filteredOffers = [...$offerData] 
            }
        }
</script>

<svelte:head>
    <title>Offers</title>    
</svelte:head>
<input class='w-full rounded-md text-lg p-4 border-2 border-gray-200' bind:value={searchTerm} type="text" placeholder="Search Offer">

    <div class='py-4 grid gap-4 md:grid-cols-3 grid-cols-1'>
        {#each filteredOffers as offerdatum}		
            <Offercard offerdatum={offerdatum}/>
        {/each}
</div>