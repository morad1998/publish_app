<script context = "module">
export async function load({fetch, params}){    
    const url = `https://pokeapi.co/api/v2/pokemon/${params.id}`;
    const res = await fetch(url);
    const offerdatum = await res.json();
    return{
        props: {offerdatum}
    };
}
</script>

<script>
    export let offerdatum;
    const type = offerdatum.types[0].type.name;
</script>


<div class="flex justify-center items-center h-screen">
<div class='card w-1/2 p-4 bg-base-80 shadow-xl'>
    <figure><img src="https://coffee.alexflipnote.dev/random" alt={offerdatum.name} /></figure>
        <div class="card-body">
          <h2 class="card-title">{offerdatum.name}</h2>
          <p>Full Description</p>
              <div class="card-actions justify-end">
                <a href="/"><button class="btn btn-primary">Use</button></a>
              </div>
        </div>
    </div>    
</div>
    
