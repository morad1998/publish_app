<script context="module">
	import { browser, dev } from '$app/env';

	// we don't need any JS on this page, though we'll load
	// it in dev so that we get hot module replacement...
	export const hydrate = dev;

	// ...but if the client-side router is already loaded
	// (i.e. we came here from elsewhere in the app), use it
	export const router = browser;

	// since there's no dynamic data here, we can prerender
	// it so that it gets served as a static asset in prod
	export const prerender = true;
</script>

<svelte:head>
	<title>Register</title>
	<meta name="description" content="Register a new user" />
</svelte:head>

<div class="content">
	<h2 class="text-3xl self-start mt-12">Login</h2>

	<div class="card w-96 bg-neutral text-neutral-content  mt-5">
		<div class="card-body items-center text-center text-white">
			<!-- email -->
			<div class="form-control w-full max-w-xs">
				<label class="label">
					<span class="label-text">email</span>
				</label>
				<input type="text" placeholder="email" class="input input-bordered w-full max-w-xs" />
			</div>

			<!-- password -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">password</span>
				</label>
				<input type="text" placeholder="password" class="input input-bordered w-full max-w-xs" />
			</div>
		</div>
	</div>
</div>


<style>
	.card-body .label-text {
		color: white !important;
	}
</style>