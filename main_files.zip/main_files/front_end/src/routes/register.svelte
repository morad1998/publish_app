<script context="module">
	import { browser, dev } from '$app/env';

	// we don't need any JS on this page, though we'll load
	// it in dev so that we get hot module replacement...
	export const hydrate = dev;

	// ...but if the client-side router is already loaded
	// (i.e. we came here from elsewhere in the app), use it
	export const router = browser;

	// since there's no dynamic data here, we can prerender
	// it so that it gets served as a static asset in prod
	export const prerender = true;
</script>

<svelte:head>
	<title>Register</title>
	<meta name="description" content="Register a new user" />
</svelte:head>

<div class="content">
	<h2 class="text-3xl self-start mt-12">Signup</h2>

	<div class="card w-96 bg-neutral text-neutral-content  mt-5">
		<div class="card-body items-center text-center text-white">
			<!-- name -->
			<div class="form-control w-full max-w-xs">
				<label class="label">
					<span class="label-text">Full name</span>
				</label>
				<input type="text" placeholder="name" class="input input-bordered w-full max-w-xs" />
			</div>

			<!-- email -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">email</span>
				</label>
				<input type="text" placeholder="email" class="input input-bordered w-full max-w-xs" />
			</div>

			<!-- password -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">password</span>
				</label>
				<input type="text" placeholder="password" class="input input-bordered w-full max-w-xs" />
			</div>

			<!-- mobile -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">Mobile</span>
				</label>
				<input type="text" placeholder="mobile" class="input input-bordered w-full max-w-xs" />
			</div>

			<!-- gender -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">Gender</span>
				</label>
				<label class="flex justify-start">
					<input type="radio" name="gender" value="male" class="radio radio-primary" /> &nbsp; Male
				</label>
				<label class="flex justify-start mt-2">
					<input type="radio" name="gender" value="female" class="radio radio-primary" /> &nbsp; Female
				</label>
			</div>

			<!-- location -->
			<div class="form-control w-full max-w-xs mt-5">
				<label class="label">
					<span class="label-text">Location</span>
				</label>

				<div class="mapouter mt-5">
					<div class="gmap_canvas">
						<iframe
							width="320"
							height="372"
							id="gmap_canvas"
							src="https://maps.google.com/maps?q=kfupm&t=&z=15&ie=UTF8&iwloc=&output=embed"
							frameborder="0"
							scrolling="no"
							marginheight="0"
							marginwidth="0"
						/><a /><br /><style>
							.mapouter {
								position: relative;
								text-align: right;
								height: 372px;
								width: 550px;
							}
						</style>
            <style>
							.gmap_canvas {
								overflow: hidden;
								background: none !important;
								height: 372px;
								width: 550px;
							}
						</style>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<style>
	.card-body .label-text {
		color: white !important;
	}
</style>
