<script context="module" lang="ts">
	export const prerender = true;
	import {offerData} from '../stores/offers'
	
</script>


<svelte:head>
	<title>Home</title>
	<meta name="description" content="Svelte demo app" />
</svelte:head>

<section>
	<!-- Hello Division -->
	<h1>		
    <div class=" card lg:card-side bg-base-100 shadow-xl">		
      <div class="hero-content text-center">
        <div class="max-w-md">
          <h1 class="text-5xl font-bold ">Most Popular Offer</h1>
          <p class="py-6">
            As per the client consuming and similarties			
          </p>
          <button class="btn btn-primary">Check Details</button>
        </div>
		<figure><img class='w-1/2 rounded' src="https://coffee.alexflipnote.dev/random" alt="Album"></figure>
      </div>
    </div>

	<!-- Search field -->

		<input class='w-full round' type="text">


	<!--  show all the offers -->
	<div class='py-4 grid gap-4 md:grid-cols-3 grid-cols-1'>
	{#each $offerData as offerdatum}		
		<div class='card w-50 bg-base-80 shadow-xl'>
			<figure><img src="https://coffee.alexflipnote.dev/random" alt={offerdatum.name} /></figure>
				<div class="card-body">
				  <h2 class="card-title">{offerdatum.name}</h2>
				  <p>short description</p>
			  		<div class="card-actions justify-end">
						<button class="btn btn-primary">More Details</button>
			 		 </div>
				</div>
			</div>
	{/each}    
</div>

</section>







<!-- by Azziz -->
<style>
	section {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		flex: 1;
	}

	h1 {
		width: 100%;
	}

	.welcome {
		display: block;
		position: relative;
		width: 100%;
		height: 0;
		padding: 0 0 calc(100% * 495 / 2048) 0;
	}

	.welcome img {
		position: absolute;
		width: 100%;
		height: 100%;
		top: 0;
		display: block;
	}


</style>
