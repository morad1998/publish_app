import { PromotionModel } from "../model/post.model";
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()
export const postUoffer = async (input: PromotionModel) => {
  const validSince = input.validSince.toDateString();
  const validThrough = input.validSince.toDateString();
  const usageLimit = input.usageLimit;
  const image = input.image.trim();
  const short_descriptin = input.short_descriptin.trim();
  const full_descriptin = input.full_descriptin.trim();
  const type = input.type.trim();
  const redeemedPoints = input.redeemedPoints;
  const allyId = input.allyId;
  // before creating we need to check existing to be discussed with Aziz.
  const newPromotion = await prisma.promotion.create({
    data: {
      validSince,
      validThrough,
      usageLimit,
      image,
      short_descriptin,
      full_descriptin,
      type,
      redeemedPoints,
      allyId,
    },

    select: {
      validSince: true,
      validThrough: true,
      usageLimit: true,
      image: true,
      short_descriptin: true,
      full_descriptin: true,
      type: true,
      redeemedPoints: true,
      allyId: true,
    },
  });

  return newPromotion;
};
