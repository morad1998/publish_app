import 'dotenv/config'
import express from 'express'
// import cors from 'cors'
import bodyParser from "body-parser";
import usersRouter from "./routes/users.js";
import offersRouter from "./routes/offers.js";

// check for env vars 
const envs = process.env
if (!envs.PORT || !envs.DATABASE_URL || !envs.JWT_TOKEN_KEY) {
  throw new Error("Not all enviroment variables are set.");
}

// setting up express app
const app = express()
const port = process.env.PORT

// middlewares
app.use(express.static('public'))
app.use(bodyParser.json())
// app.use(cors({
//   credentials: true,
//   //To allow requests from client
//   origin: [
//     process.env.ALLOWED_ORIGIN,
//     `http://localhost:${port}`,
//     "http://localhost:3000",
//     "http://127.0.0.1",
//   ],
// }))



// 
// routes
// 
app.use('/api/users', usersRouter())
app.use('/api/offers', offersRouter())

// run server
app.listen(port, () => {
  console.log(`app is listening on  http://localhost:${port}`)
})