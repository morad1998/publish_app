export interface PromotionModel {
    validSince: Date;
    validThrough: Date;
    usageLimit: number;
    image: string;
    short_descriptin: string;
    full_descriptin: string;
    type: string;
    redeemedPoints: number;
    allyId: number
}
    
  