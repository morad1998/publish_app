import { PrismaClient } from '@prisma/client' //added by Morad
import express from "express";
import { Router, Request, Response, NextFunction} from 'express'; //added by Morad
import {postUoffer} from '../services/offer.services' //added by Morad
const prisma = new PrismaClient(); //added by Morad
const router = express.Router()
const router_ = Router() // Added by Morad
router.use(express.json()); //added by Morad
router.use(express.urlencoded()); //added by Morad

export default () => {

  // 
  // endpoints
  // 
  router.get('/', async (req:Request, res:Response, next:NextFunction) => {

    try {
      const offAll = await prisma.promotion.findMany(
        {
        where: {
          validThrough: {              
               gte: new Date()                         
           }
        },
        orderBy: {
          id: "desc",
        },
      });
  
      res.json({ offAll });
    } catch (error: any) {
      next(error);
    }
    
  })

  router.post('/', async (req: Request, res: Response,next: NextFunction) => {


    // TODO
    jwt.verify(req.token, 'secretkey', (err, authData) =>{
      if (err) {
        res.sendStatus(403);
      } else {
        
        try {
          const postUniqueoffer = await postUoffer(req.body.postOfferAlly);
          res.json({ message: 'Created...',
          authData
          })
        
        } catch (err) {
          next(err);
        
        }

      }
    })
    


  })

  router.get('/:id', async (req: Request, res: Response , next: NextFunction) => {

    try {
      const offAllid = await prisma.promotion.findUnique({
        where: {
          id: Number(req.params.id),
        },
      });
  
      res.json({ offAllid });
    }catch (error: any) {
      next(error.message);
    }
    
  })

  // ...

  return router
}

//------------------------------------------------------
// Verify Token
function verifyToken(req, res, next) {
  // Get auth header value
  const bearerHeader = req.headers['authorization'];
  // Check if bearer is undefined
  if(typeof bearerHeader !== 'undefined') {
    // Split at the space
    const bearer = bearerHeader.split(' ');
    // Get token from array
    const bearerToken = bearer[1];
    // Set the token
    req.token = bearerToken;
    // Next middleware
    next();
  } else {
    // Forbidden
    res.sendStatus(403);
  }

}

//---------------------------------------------------------