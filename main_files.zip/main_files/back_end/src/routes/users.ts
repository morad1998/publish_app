import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import express from "express";
import { body, validationResult } from 'express-validator';
import { PrismaClient, User } from '@prisma/client';

const HASH_ROUNDS = 10

const prisma = new PrismaClient()
const router = express.Router()


async function isUserAdminOverAllies(userId: number | undefined) {
  const allies = await prisma.allyAdmin.findMany({
    select: {
      allyId: true,
    },
    where: {
      adminId: userId
    }
  });

  return allies.map(obj => obj.allyId);
}

function generateJwtToken(user: User, adminOver?: number[]) {
  const token = {
    userId: user.id,
    allyId: user.allyId,
    adminOver,
  }

  return token;
}

export default () => {

  // 
  // endpoints
  // 
  router.post('/register',
    // validations
    body('email').isEmail().normalizeEmail(),
    body('mobile').isMobilePhone('ar-SA'),
    body('gender').not().isEmpty().trim().escape().toLowerCase().isIn(['male', 'female']),
    body('password').not().isEmpty().trim().escape().isLength({ min: 8 }),
    body('name').not().isEmpty().trim().escape().isLength({ min: 2 }),
    body('location').not().isEmpty().trim().escape(),
    // route handler
    async (req, res) => {
      // check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      // Get user input
      const { name, email, mobile, gender, password, location, age } = req.body;

      try {
        // check if email already registered in the database 
        const isOldUser = await prisma.user.findFirst({ where: { email } })

        if (isOldUser) {
          return res.status(409).send("Email already exist. Please login");
        }

        //Encrypt user password
        const encryptedPassword = await bcrypt.hash(password, HASH_ROUNDS);

        // check if user is a member of ally
        const emailDomain = email.split('@')[1]
        const isAllyRegistered = await prisma.ally.findFirst({ where: { domain: emailDomain } })

        // Create user in our database
        const user = await prisma.user.create({
          data: {
            name,
            gender,
            age,
            email,
            password: encryptedPassword,
            mobileNumber: mobile,
            country: location,
            city: location,
            allyId: isAllyRegistered?.id,
          }
        })

        // Create JWT token
        const token = jwt.sign(
          generateJwtToken(user),
          process.env.JWT_TOKEN_KEY!
        );

        res.status(201).json({ userInfo: user, token });
      } catch (err) {
        // TODO: add a proper logger
        console.log(err);
      }
    })

  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;

      // Validate user input
      if (!(email && password)) {
        res.status(400).send("All input fields are required");
      }
      // Validate if user exist in our database
      const user = await prisma.user.findFirst({ where: { email } });

      if (user && (await bcrypt.compare(password, user.password))) {
        const isAdminOverAllies = await isUserAdminOverAllies(user.id);

        // Create JWT token
        const token = jwt.sign(
          generateJwtToken(user),
          process.env.JWT_TOKEN_KEY!
        );

        // user
        return res.status(200).json({ userInfo: user, token });
      }
      res.status(400).send("Invalid Credentials");
    } catch (err) {
      // TODO: add a proper logger
      console.log(err);
    }
  })

  return router
}