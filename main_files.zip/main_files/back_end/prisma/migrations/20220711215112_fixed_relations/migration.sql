/*
  Warnings:

  - You are about to drop the column `ageGroup` on the `User` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[domain]` on the table `Ally` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `password` to the `User` table without a default value. This is not possible if the table is not empty.

*/
-- CreateTable
CREATE TABLE "AllyAdmin" (
    "allyId" INTEGER NOT NULL,
    "adminId" INTEGER NOT NULL,

    PRIMARY KEY ("allyId", "adminId"),
    CONSTRAINT "AllyAdmin_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "AllyAdmin_allyId_fkey" FOREIGN KEY ("allyId") REFERENCES "Ally" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Redemption" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER NOT NULL,
    "date" DATETIME NOT NULL,
    "redeemedPoints" INTEGER NOT NULL,
    "branchId" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL,
    CONSTRAINT "Redemption_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Redemption_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_Redemption" ("branchId", "date", "id", "productId", "redeemedPoints", "userId") SELECT "branchId", "date", "id", "productId", "redeemedPoints", "userId" FROM "Redemption";
DROP TABLE "Redemption";
ALTER TABLE "new_Redemption" RENAME TO "Redemption";
CREATE TABLE "new_User" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "mobileNumber" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "gender" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "age" INTEGER,
    "points" INTEGER NOT NULL DEFAULT 0,
    "joiningDate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "allyId" INTEGER,
    CONSTRAINT "User_allyId_fkey" FOREIGN KEY ("allyId") REFERENCES "Ally" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_User" ("allyId", "city", "country", "email", "gender", "id", "joiningDate", "mobileNumber", "name", "points") SELECT "allyId", "city", "country", "email", "gender", "id", "joiningDate", "mobileNumber", "name", "points" FROM "User";
DROP TABLE "User";
ALTER TABLE "new_User" RENAME TO "User";
CREATE TABLE "new_BillItem" (
    "billId" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL,
    "itemCount" INTEGER NOT NULL,

    PRIMARY KEY ("productId", "billId"),
    CONSTRAINT "BillItem_billId_fkey" FOREIGN KEY ("billId") REFERENCES "Bill" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "BillItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_BillItem" ("billId", "itemCount", "productId") SELECT "billId", "itemCount", "productId" FROM "BillItem";
DROP TABLE "BillItem";
ALTER TABLE "new_BillItem" RENAME TO "BillItem";
PRAGMA foreign_key_check;
PRAGMA foreign_keys=ON;

-- CreateIndex
CREATE UNIQUE INDEX "Ally_domain_key" ON "Ally"("domain");
