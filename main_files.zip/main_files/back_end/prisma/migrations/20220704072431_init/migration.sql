-- CreateTable
CREATE TABLE "User" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "mobileNumber" TEXT NOT NULL,
    "joiningDate" DATETIME NOT NULL,
    "gender" TEXT NOT NULL,
    "ageGroup" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "points" INTEGER NOT NULL,
    "allyId" INTEGER NOT NULL,
    CONSTRAINT "User_allyId_fkey" FOREIGN KEY ("allyId") REFERENCES "Ally" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Ally" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "domain" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "Bill" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER NOT NULL,
    "merchantId" INTEGER NOT NULL,
    "branchId" INTEGER NOT NULL,
    "itemCount" INTEGER NOT NULL,
    "pointsRedeemed" INTEGER NOT NULL,
    "amount" REAL NOT NULL,
    "discount" REAL NOT NULL,
    "tax" REAL NOT NULL,
    "total" REAL NOT NULL,
    "promotionId" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "BillItem" (
    "billId" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL,
    "itemCount" INTEGER NOT NULL,

    PRIMARY KEY ("productId", "billId"),
    CONSTRAINT "BillItem_billId_fkey" FOREIGN KEY ("billId") REFERENCES "Bill" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Product" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "merchantId" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "price" REAL NOT NULL,
    "image" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    CONSTRAINT "Product_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "Merchant" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Merchant" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "logo" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "joiningDate" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Branch" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "merchantId" INTEGER NOT NULL,
    "latitude" REAL NOT NULL,
    "longitude" REAL NOT NULL,
    CONSTRAINT "Branch_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "Merchant" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Redemption" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER NOT NULL,
    "date" DATETIME NOT NULL,
    "redeemedPoints" INTEGER NOT NULL,
    "branchId" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "Promotion" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "validSince" DATETIME NOT NULL,
    "validThrough" DATETIME NOT NULL,
    "usageLimit" INTEGER NOT NULL,
    "image" TEXT NOT NULL,
    "short_descriptin" TEXT NOT NULL,
    "full_descriptin" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "redeemedPoints" INTEGER NOT NULL,
    "allyId" INTEGER,
    CONSTRAINT "Promotion_allyId_fkey" FOREIGN KEY ("allyId") REFERENCES "Ally" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "MerchantPromotion" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "merchantId" INTEGER NOT NULL,
    "redeemedPoints" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "AllyPromotion" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "allyId" INTEGER NOT NULL,
    "givenPoints" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL,
    "merchantId" INTEGER NOT NULL,
    CONSTRAINT "AllyPromotion_allyId_fkey" FOREIGN KEY ("allyId") REFERENCES "Ally" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ProductPromotion" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "productId" INTEGER NOT NULL,
    "redeemedPoints" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "PromotionUser" (
    "userId" INTEGER NOT NULL,
    "promotionId" INTEGER NOT NULL,

    PRIMARY KEY ("userId", "promotionId")
);
